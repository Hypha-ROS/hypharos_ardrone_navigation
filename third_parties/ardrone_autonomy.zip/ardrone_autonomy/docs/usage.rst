==================
Usage
==================

The driver's executable node is ``ardrone_driver``. You can either run ``rosrun ardrone_autonomy ardrone_driver`` directly or use a custom launch file with your desired parameters. Example launch files are located in the ``launch`` directory.

