=======
License
=======

- `The Parrot's license, copyright and disclaimer for ARDroneLib <https://github.com/AutonomyLab/ardronelib/blob/master/LICENSE>`_

- Other parts of the code are subject to `BSD license <http://opensource.org/licenses/BSD-3-Clause>`_
